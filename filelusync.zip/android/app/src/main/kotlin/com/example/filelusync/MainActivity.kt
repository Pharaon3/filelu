package com.example.filelusync

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
